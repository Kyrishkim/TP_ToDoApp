package com.example.todoapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.content.Context
import com.google.firebase.database.FirebaseDatabase
import android.widget.Toast

class TaskAdapter(
    private val context: Context,
    private val taskList: MutableList<Task>,
    private val onEditClick: (Task, Int) -> Unit,
    private val onDeleteClick: (Int) -> Unit
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    inner class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewTask: TextView = itemView.findViewById(R.id.textViewTask)
        val buttonEdit: Button = itemView.findViewById(R.id.buttonEdit)
        val buttonDelete: Button = itemView.findViewById(R.id.buttonDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = taskList[position]
        holder.textViewTask.text = task.task

        holder.buttonEdit.setOnClickListener {
            onEditClick(task, position)
        }

        holder.buttonDelete.setOnClickListener {
            onDeleteClick(position)
        }
    }

    override fun getItemCount(): Int {
        return taskList.size
    }

    fun addTask(task: Task) {
        taskList.add(task)
        notifyItemInserted(taskList.size - 1)
    }

    fun updateTask(position: Int, updatedTask: String) {
        val task = taskList[position]
        task.task = updatedTask
        notifyItemChanged(position)

        val database =
            FirebaseDatabase.getInstance("https://todoapp-72ec5-default-rtdb.asia-southeast1.firebasedatabase.app").getReference("task")
        database.child(task.id).setValue(task)
            .addOnSuccessListener {
                Toast.makeText(context, "Task updated", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(context, "Failed to update task", Toast.LENGTH_SHORT).show()
            }
    }

    fun deleteTask(position: Int) {
        val task = taskList[position]

        val database = FirebaseDatabase.getInstance("https://todoapp-72ec5-default-rtdb.asia-southeast1.firebasedatabase.app").getReference("task")
        database.child(task.id).removeValue() // ✔️ delete specific task only
            .addOnSuccessListener {
                Toast.makeText(context, "Task deleted", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(context, "Failed to delete task", Toast.LENGTH_SHORT).show()
            }

        taskList.removeAt(position)
        notifyItemRemoved(position)
    }
}