package com.example.todoapp

data class Task(
    val id: String = "",
    var task: String = ""
)
