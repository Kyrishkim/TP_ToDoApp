package com.example.todoapp

import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.FirebaseDatabase
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {

    private lateinit var editTextTask: EditText
    private lateinit var buttonAddTask: Button
    private lateinit var recyclerViewTasks: RecyclerView
    private lateinit var adapter: TaskAdapter
    private val taskList = mutableListOf<Task>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val database = FirebaseDatabase.getInstance("https://todoapp-72ec5-default-rtdb.asia-southeast1.firebasedatabase.app")
        val taskRef = database.getReference("task")


        editTextTask = findViewById(R.id.editTextTask)
        buttonAddTask = findViewById(R.id.buttonAddTask)
        recyclerViewTasks = findViewById(R.id.recyclerViewTasks)

        adapter = TaskAdapter(
            this,  // context ng activity
            taskList,
            onEditClick = { task, position -> showEditDialog(task, position) },
            onDeleteClick = { position -> adapter.deleteTask(position) }
        )

        recyclerViewTasks.layoutManager = LinearLayoutManager(this)
        recyclerViewTasks.adapter = adapter

        buttonAddTask.setOnClickListener {
            val taskText = editTextTask.text.toString().trim()

            if (taskText.isNotEmpty()) {
                val taskId = taskRef.push().key ?: return@setOnClickListener
                val task = Task(taskId, taskText)

                taskRef.child(taskId).setValue(task)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Task added", Toast.LENGTH_SHORT).show()
                        editTextTask.text.clear()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Failed to add task", Toast.LENGTH_SHORT).show()
                    }
            } else {
                Toast.makeText(this, "Please enter a task", Toast.LENGTH_SHORT).show()
            }
        }


//               Temporary without Firebase, just add locally:
//                val fakeId = System.currentTimeMillis().toString()
//                val task = Task(fakeId, taskText)
//                taskList.add(task)
//                adapter.notifyItemInserted(taskList.size - 1)
//                editTextTask.text.clear()
//                Toast.makeText(this, "Task added locally", Toast.LENGTH_SHORT).show()




        taskRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                taskList.clear() // clear existing tasks
                for (taskSnapshot in snapshot.children) {
                    val task = taskSnapshot.getValue(Task::class.java)
                    task?.let { taskList.add(it) }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed to load tasks", Toast.LENGTH_SHORT).show()
            }
        })

    }

    private fun showEditDialog(task: Task, position: Int) {
        val editText = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(task.task)
        }

        AlertDialog.Builder(this)
            .setTitle("Edit Task")
            .setView(editText)
            .setPositiveButton("Save") { _, _ ->
                val newTaskText = editText.text.toString().trim()
                if (newTaskText.isNotEmpty()) {
                    adapter.updateTask(position, newTaskText) // ito tatawag sa Firebase update
                } else {
                    Toast.makeText(this, "Task cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    }